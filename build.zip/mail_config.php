<?php

return [
    // Delivery mode: 'smtp' (recommended) or 'mail' (fallback).
    'mode' => 'smtp',

    // SMTP settings (used when mode = 'smtp').
    'smtp' => [
        'host' => 'mail.uburumultimovehs.org',
        'port' => 465,
        'secure' => 'ssl', // 'tls' or 'ssl'
        'username' => 'no-reply@uburumultimovehs.org',
        'password' => 'Uburumul@123',
    ],

    // From identity shown to recipients.
    'from' => [
        'email' => 'no-reply@uburumultimovehs.org',
        'name' => 'Uburu Multimove',
    ],

    // Recipients.
    // You can set a single catch-all inbox via 'default', or override per form.
    'to' => [
        'default' => 'uburumultimovess@gmail.com',
        'contact' => 'uburumultimovess@gmail.com',
        'volunteer' => 'uburumultimovess@gmail.com',
        'donate_items' => 'uburumultimovess@gmail.com',
        'therapy' => 'uburumultimovess@gmail.com',
        'purchases' => 'uburumultimovess@gmail.com',
    ],

    // Basic abuse protection.
    'rate_limit' => [
        'window_seconds' => 300,
        'max_requests' => 5,
    ],
];
